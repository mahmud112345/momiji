"""Momiji'ye çeviri servisini ekler: manifest + gradle bağımlılıkları."""
import pathlib
import re
import sys

root = pathlib.Path(".")

# ---- AndroidManifest.xml ----
man = root / "android/app/src/main/AndroidManifest.xml"
if not man.exists():
    sys.exit("HATA: AndroidManifest.xml bulunamadi: %s" % man)
m = man.read_text(encoding="utf-8")

if "com.oyuncevir.ceviri" not in m:
    perms = [
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.FOREGROUND_SERVICE",
        "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION",
        "android.permission.POST_NOTIFICATIONS",
        "android.permission.INTERNET",
    ]
    add_perm = "".join(
        '    <uses-permission android:name="%s" />\n' % p
        for p in perms
        if ('"%s"' % p) not in m
    )
    i = m.find("<application")
    if i < 0:
        sys.exit("HATA: <application> etiketi bulunamadi")
    m = m[:i] + add_perm + "    " + m[i:]

    comps = """
        <activity
            android:name="com.oyuncevir.ceviri.CeviriActivity"
            android:exported="true"
            android:label="Oyun Çeviri"
            android:theme="@android:style/Theme.Material.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <service
            android:name="com.oyuncevir.ceviri.CaptureService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection" />
    """
    j = m.rfind("</application>")
    if j < 0:
        sys.exit("HATA: </application> etiketi bulunamadi")
    m = m[:j] + comps + m[j:]
    man.write_text(m, encoding="utf-8")
    print("Manifest yamalandi")
else:
    print("Manifest zaten yamali")

# ---- app/build.gradle(.kts) ----
gfile = None
for name in ("build.gradle.kts", "build.gradle"):
    p = root / "android/app" / name
    if p.exists():
        gfile = p
        break
if gfile is None:
    sys.exit("HATA: android/app/build.gradle(.kts) bulunamadi")

g = gfile.read_text(encoding="utf-8")
if "mlkit:translate" not in g:
    mm = re.search(r"^dependencies\s*\{", g, re.M)
    if not mm:
        sys.exit("HATA: dependencies blogu bulunamadi: %s" % gfile)
    deps = (
        '\n    implementation("com.google.mlkit:text-recognition:16.0.1")'
        '\n    implementation("com.google.mlkit:translate:17.0.3")'
    )
    g = g[: mm.end()] + deps + g[mm.end():]
    gfile.write_text(g, encoding="utf-8")
    print("Gradle yamalandi:", gfile)
else:
    print("Gradle zaten yamali")
