package com.oyuncevir.ceviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {

    companion object {
        var running = false
        const val CHANNEL = "ceviri"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var capW = 0
    private var capH = 0

    private lateinit var panel: View
    private lateinit var subtitle: TextView
    private lateinit var subtitleParams: WindowManager.LayoutParams
    private lateinit var toggleChip: TextView
    private var selector: View? = null

    // Seçilen bölge: ekran boyutuna oranla (0..1)
    private var rl = 0f
    private var rt = 0f
    private var rr = 0f
    private var rb = 0f
    private var hasRegion = false

    private var translating = false
    private var busy = false
    private var modelReady = false
    private var subtitleAtTop = true

    private var emptyCount = 0
    private var lastOcr = ""
    private var lastSrc = ""
    private var lastRaw = ""
    private var pending: Runnable? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.TURKISH)
            .build()
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (running) return START_NOT_STICKY

        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }
        projection?.registerCallback(projectionCallback!!, main)

        setupCapture()
        buildOverlays()
        prepareTranslator()
        main.postDelayed(loop, 800)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Çeviri", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        val n = builder
            .setContentTitle("Oyun Çeviri çalışıyor")
            .setContentText("Durdurmak için dokun")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun realSize(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    // ---- Ekran yakalama ----

    private fun setupCapture() {
        val (w, h, dpi) = realSize()
        capW = w
        capH = h
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = vdisplay
        if (vd == null) {
            vdisplay = projection!!.createVirtualDisplay(
                "oyuncevir", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = r.surface
        }
        reader?.close()
        reader = r
    }

    private val loop = object : Runnable {
        override fun run() {
            if (translating && hasRegion && !busy) captureAndRead()
            main.postDelayed(this, 700)
        }
    }

    private fun captureAndRead() {
        val (w, h, _) = realSize()
        if (w != capW || h != capH) {
            setupCapture() // ekran döndü
            return
        }
        val image = reader?.acquireLatestImage() ?: return
        var crop: Bitmap? = null
        try {
            val plane = image.planes[0]
            val rowPx = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPx, image.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val x = (rl * image.width).toInt().coerceIn(0, image.width - 2)
            val y = (rt * image.height).toInt().coerceIn(0, image.height - 2)
            val cw = ((rr - rl) * image.width).toInt().coerceIn(2, image.width - x)
            val ch = ((rb - rt) * image.height).toInt().coerceIn(2, image.height - y)
            crop = Bitmap.createBitmap(full, x, y, cw, ch)
            full.recycle()
        } catch (e: Exception) {
            crop = null
        } finally {
            image.close()
        }
        val bmp = crop ?: return
        busy = true
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { onOcr(it.text) }
            .addOnFailureListener { busy = false }
            .addOnCompleteListener { bmp.recycle() }
    }

    // ---- OCR ve çeviri ----

    private fun onOcr(raw: String) {
        busy = false
        val text = raw.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        if (text.length < 3) {
            emptyCount++
            if (emptyCount >= 3) {
                lastOcr = ""
                lastSrc = ""
                lastRaw = ""
                pending?.let { main.removeCallbacks(it) }
                showSubtitle("")
            }
            return
        }
        emptyCount = 0
        val key = text.lowercase().filter { it.isLetterOrDigit() }
        if (key == lastOcr) return
        lastOcr = key
        lastRaw = text
        pending?.let { main.removeCallbacks(it) }
        val r = Runnable { translateNow(text, key) }
        pending = r
        main.postDelayed(r, 500) // yazı oturana kadar kısa bekle
    }

    private fun translateNow(text: String, key: String) {
        if (!modelReady) return
        if (key == lastSrc) return
        lastSrc = key
        translator.translate(text)
            .addOnSuccessListener { showSubtitle(it) }
            .addOnFailureListener { showSubtitle("Çeviri hatası") }
    }

    private fun prepareTranslator() {
        showSubtitle("Çeviri modeli indiriliyor (internet gerekir)…")
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                modelReady = true
                showSubtitle("")
                if (lastRaw.isNotEmpty()) translateNow(lastRaw, lastOcr)
            }
            .addOnFailureListener {
                showSubtitle("Model indirilemedi, interneti kontrol et")
            }
    }

    private fun showSubtitle(t: String) {
        if (t.isBlank()) {
            subtitle.visibility = View.GONE
            return
        }
        val (w, _, _) = realSize()
        subtitle.maxWidth = (w * 0.9).toInt()
        subtitle.text = t
        subtitle.visibility = View.VISIBLE
    }

    // ---- Üstte görünen arayüz ----

    private fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { onClick() }
    }

    @Suppress("DEPRECATION")
    private fun overlayParams(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        flags, PixelFormat.TRANSLUCENT
    )

    private fun buildOverlays() {
        // Altyazı
        subtitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(0xCC000000.toInt())
                cornerRadius = dp(10).toFloat()
            }
            visibility = View.GONE
        }
        subtitleParams = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(subtitle, subtitleParams)

        // Kontrol paneli
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                setColor(0x99000000.toInt())
                cornerRadius = dp(14).toFloat()
            }
        }
        val panelParams = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(90)
        }

        val handle = chip("≡") {}
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = panelParams.x; startY = panelParams.y
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = startX + (e.rawX - downX).toInt()
                    panelParams.y = startY + (e.rawY - downY).toInt()
                    wm.updateViewLayout(panel, panelParams)
                }
            }
            true
        }

        toggleChip = chip("▶") {
            if (hasRegion) {
                translating = !translating
                toggleChip.text = if (translating) "⏸" else "▶"
                if (!translating) showSubtitle("")
            }
        }

        bar.addView(handle)
        bar.addView(chip("Bölge") { startSelecting() })
        bar.addView(toggleChip)
        bar.addView(chip("↕") { moveSubtitle() })
        bar.addView(chip("✕") { stopSelf() })
        panel = bar
        wm.addView(panel, panelParams)
    }

    private fun moveSubtitle() {
        subtitleAtTop = !subtitleAtTop
        subtitleParams.gravity =
            (if (subtitleAtTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        wm.updateViewLayout(subtitle, subtitleParams)
    }

    // ---- Bölge seçme ----

    private fun startSelecting() {
        if (selector != null) return
        val v = SelectView(this) { l, t, r, b -> finishSelect(l, t, r, b) }
        val p = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        wm.addView(v, p)
        selector = v
    }

    private fun removeSelector() {
        selector?.let { runCatching { wm.removeView(it) } }
        selector = null
    }

    private fun finishSelect(l: Int, t: Int, r: Int, b: Int) {
        removeSelector()
        if (l < 0) return
        val (w, h, _) = realSize()
        rl = (l / w.toFloat()).coerceIn(0f, 1f)
        rr = (r / w.toFloat()).coerceIn(0f, 1f)
        rt = (t / h.toFloat()).coerceIn(0f, 1f)
        rb = (b / h.toFloat()).coerceIn(0f, 1f)
        hasRegion = true
        translating = true
        toggleChip.text = "⏸"
        lastOcr = ""
        lastSrc = ""
        lastRaw = ""
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) {
            runCatching { wm.removeView(panel) }
            runCatching { wm.removeView(subtitle) }
            removeSelector()
        }
        vdisplay?.release()
        reader?.close()
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}

private class SelectView(
    ctx: Context,
    val onDone: (Int, Int, Int, Int) -> Unit
) : View(ctx) {
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var drawing = false
    private val rectPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 44f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    init {
        setBackgroundColor(0x66000000)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y; ex = sx; ey = sy; drawing = true
            }
            MotionEvent.ACTION_MOVE -> {
                ex = e.x; ey = e.y
            }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y; drawing = false
                val loc = IntArray(2)
                getLocationOnScreen(loc)
                val l = minOf(sx, ex).toInt() + loc[0]
                val t = minOf(sy, ey).toInt() + loc[1]
                val r = maxOf(sx, ex).toInt() + loc[0]
                val b = maxOf(sy, ey).toInt() + loc[1]
                if (r - l > 40 && b - t > 20) onDone(l, t, r, b) else onDone(-1, -1, -1, -1)
                return true
            }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        if (!drawing) {
            c.drawText("Çevrilecek yazının üstünü parmağınla çiz", width / 2f, height / 2f, textPaint)
        } else {
            c.drawRect(minOf(sx, ex), minOf(sy, ey), maxOf(sx, ex), maxOf(sy, ey), rectPaint)
        }
    }
}
