package com.oyuncevir.ceviri

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class CeviriActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.BLACK)
        }
        val info = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            text = "Oyun Çeviri\n\n" +
                "1) 'Üstte gösterme izni' ver.\n" +
                "2) 'Başlat'a bas, ekran yakalamaya izin ver.\n" +
                "3) 'Momiji'yi aç'a bas, PS5'ine bağlan.\n" +
                "4) Yayın başlayınca üstteki küçük panelden 'Bölge'ye bas, " +
                "yazının çıktığı yeri parmağınla çiz.\n" +
                "5) Çeviri ekranın üstünde görünür. ↕ ile alta alabilirsin.\n\n" +
                "İlk açılışta çeviri modeli iner (internet gerekir). " +
                "Şimdilik İngilizce'den Türkçe'ye çevirir."
        }
        val btnOverlay = Button(this).apply {
            text = "1) Üstte gösterme izni"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@CeviriActivity)) {
                    Toast.makeText(this@CeviriActivity, "İzin zaten verilmiş", Toast.LENGTH_SHORT).show()
                } else {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        }
        val btnStart = Button(this).apply {
            text = "2) Başlat"
            setOnClickListener { start() }
        }
        val btnMomiji = Button(this).apply {
            text = "3) Momiji'yi aç"
            setOnClickListener { openMomiji() }
        }
        val btnStop = Button(this).apply {
            text = "Çeviriyi durdur"
            setOnClickListener {
                startService(Intent(this@CeviriActivity, CaptureService::class.java).setAction("STOP"))
            }
        }
        root.addView(info)
        root.addView(btnOverlay)
        root.addView(btnStart)
        root.addView(btnMomiji)
        root.addView(btnStop)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(root)
        })
    }

    private fun openMomiji() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(packageName)
        val target = packageManager.queryIntentActivities(q, 0)
            .map { it.activityInfo }
            .firstOrNull { it.name != CeviriActivity::class.java.name }
        if (target == null) {
            Toast.makeText(this, "Momiji ana ekranı bulunamadı, uygulama simgesinden aç", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(
            Intent().setClassName(target.packageName, target.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Önce üstte gösterme iznini ver", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            Toast.makeText(this, "Başladı. Şimdi Momiji'yi aç", Toast.LENGTH_LONG).show()
        }
    }
}
