"""Momiji'yi tek uygulamaya (Oyunca) dönüştürür: çeviri servisi + yeni ad/simge + tek açılış ekranı."""
import pathlib
import re
import sys

root = pathlib.Path(".")
APP = "Oyunca"

man = root / "android/app/src/main/AndroidManifest.xml"
if not man.exists():
    sys.exit("HATA: AndroidManifest.xml bulunamadi: %s" % man)
m = man.read_text(encoding="utf-8")

# ---- app/build.gradle(.kts) ----
gfile = None
for name in ("build.gradle.kts", "build.gradle"):
    p = root / "android/app" / name
    if p.exists():
        gfile = p
        break
if gfile is None:
    sys.exit("HATA: android/app/build.gradle(.kts) bulunamadi")
g = gfile.read_text(encoding="utf-8")

# Paket adi (Momiji'nin etkinlik adlarini tam sinif adina cevirmek icin)
ns = None
mm = re.search(r'namespace\s*=?\s*["\']([^"\']+)["\']', g)
if mm:
    ns = mm.group(1)
else:
    mp = re.search(r'<manifest[^>]*\spackage="([^"]+)"', m)
    if mp:
        ns = mp.group(1)

if "com.oyuncevir.ceviri" in m:
    print("Manifest zaten yamali")
else:
    # 1) Momiji'nin kendi acilis simgesini kaldir: tek simge Oyunca olsun
    #    (PS5 baglantisi Ps5Launcher.kt ile dogrudan Momiji'nin ana ekranina acilir)
    m = re.sub(
        r'<category\s+android:name="android\.intent\.category\.LAUNCHER"\s*/>',
        "", m)

    # 2) Izinler
    perms = [
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.FOREGROUND_SERVICE",
        "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION",
        "android.permission.POST_NOTIFICATIONS",
        "android.permission.INTERNET",
    ]
    add_perm = "".join(
        '    <uses-permission android:name="%s" />\n' % p
        for p in perms if ('"%s"' % p) not in m)
    i = m.find("<application")
    if i < 0:
        sys.exit("HATA: <application> etiketi bulunamadi")
    m = m[:i] + add_perm + "    " + m[i:]

    # 3) Uygulama adi ve simgesi
    a = m.find("<application")
    b = m.find(">", a)
    tag = m[a:b]
    tag = re.sub(r'\s+android:(icon|roundIcon)="[^"]*"', "", tag)
    if re.search(r'android:label="[^"]*"', tag):
        tag = re.sub(r'android:label="[^"]*"', 'android:label="%s"' % APP, tag)
    else:
        tag += '\n        android:label="%s"' % APP
    tag += '\n        android:icon="@drawable/oyunca_icon"'
    m = m[:a] + tag + m[b:]

    # 4) Bilesenler
    comps = """
        <activity
            android:name="com.oyuncevir.ceviri.CeviriActivity"
            android:exported="true"
            android:label="Oyunca"
            android:theme="@android:style/Theme.Material.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <service
            android:name="com.oyuncevir.ceviri.CaptureService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection" />
    """
    j = m.rfind("</application>")
    if j < 0:
        sys.exit("HATA: </application> etiketi bulunamadi")
    m = m[:j] + comps + m[j:]
    man.write_text(m, encoding="utf-8")
    print("Manifest yamalandi")

# ---- Gradle bagimliliklari ----
if "mlkit:translate" not in g:
    mm = re.search(r"^dependencies\s*\{", g, re.M)
    if not mm:
        sys.exit("HATA: dependencies blogu bulunamadi: %s" % gfile)
    deps = (
        '\n    implementation("com.google.mlkit:text-recognition:16.0.1")'
        '\n    implementation("com.google.mlkit:translate:17.0.3")'
    )
    g = g[: mm.end()] + deps + g[mm.end():]
    gfile.write_text(g, encoding="utf-8")
    print("Gradle yamalandi:", gfile)
else:
    print("Gradle zaten yamali")

# ---- Gorunen "Momiji" yazilari ----
for sf in (root / "android/app/src/main/res").glob("values*/strings.xml"):
    try:
        s = sf.read_text(encoding="utf-8")
        s2 = s.replace("Momiji", APP).replace("MOMIJI", APP.upper())
        if s2 != s:
            sf.write_text(s2, encoding="utf-8")
            print("Ad degistirildi:", sf)
    except Exception as e:
        print("Uyari:", sf, e)
