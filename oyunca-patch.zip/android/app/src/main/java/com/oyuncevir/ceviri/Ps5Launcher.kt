package com.oyuncevir.ceviri

import android.content.Context
import android.content.Intent
import com.metallic.chiaki.main.MainActivity
import com.metallic.chiaki.shortcut.ConsoleShortcuts

/** Momiji'nin ana ekranına ve "son oynanan konsola otomatik bağlan" özelliğine bağlanır. */
object Ps5Launcher {
    fun available(): Boolean = true

    fun consoleName(ctx: Context): String? = ConsoleShortcuts.lastPlayed(ctx)?.name

    fun intent(ctx: Context): Intent? {
        val c = ConsoleShortcuts.lastPlayed(ctx)
        val i = if (c != null) MainActivity.playIntent(ctx, c.mac, c.name)
        else Intent(ctx, MainActivity::class.java)
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
