package com.oyuncevir.ceviri

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class CeviriActivity : Activity() {

    private lateinit var ui: UiKit
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var statusChip: TextView
    private lateinit var permChip: TextView
    private lateinit var mainBtn: TextView
    private lateinit var segOffline: TextView
    private lateinit var segGemini: TextView
    private lateinit var engineDesc: TextView
    private lateinit var geminiBox: LinearLayout
    private lateinit var langRow: LinearLayout
    private lateinit var langBtn: TextView
    private lateinit var sizeLabel: TextView
    private lateinit var consoleInfo: TextView

    private val langNames = arrayOf("İngilizce", "Almanca", "Fransızca", "İspanyolca", "İtalyanca", "Portekizce")
    private val langCodes = arrayOf("en", "de", "fr", "es", "it", "pt")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = UiKit(this)
        window.statusBarColor = Pal.BG
        window.navigationBarColor = Pal.BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ui.dp(18), ui.dp(44), ui.dp(18), ui.dp(28))

        // Başlık
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(ui.label("Oyunca", 30f, Pal.TEXT, true))
        titles.addView(ui.label("Oyunlara anlık Türkçe altyazı", 14f, Pal.MUTED))
        head.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        statusChip = ui.label("Hazır", 13f, Color.WHITE, true)
        statusChip.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6))
        head.addView(statusChip)
        root.addView(head, ui.lp(0, 18))

        // Başlat
        mainBtn = ui.button("▶  Başlat", Pal.ACCENT) { onMainClick() }
        root.addView(mainBtn, ui.lp(0, 10))
        consoleInfo = ui.label("", 12f, Pal.MUTED)
        consoleInfo.gravity = Gravity.CENTER
        if (Ps5Launcher.available()) root.addView(consoleInfo, ui.lp(0, 10))
        if (Ps5Launcher.available()) {
            root.addView(
                ui.button("Sadece PS5'e bağlan (çevirisiz)", Pal.FIELD, Pal.TEXT) { openMomiji() },
                ui.lp(0, 14)
            )
        }

        // İzin
        val permCard = ui.card()
        val permRow = LinearLayout(this)
        permRow.orientation = LinearLayout.HORIZONTAL
        permRow.gravity = Gravity.CENTER_VERTICAL
        val permTexts = LinearLayout(this)
        permTexts.orientation = LinearLayout.VERTICAL
        permTexts.addView(ui.label("Üstte gösterme izni", 15f, Pal.TEXT, true))
        permTexts.addView(ui.label("Altyazının oyunun üstünde görünmesi için gerekli", 12f, Pal.MUTED))
        permRow.addView(permTexts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        permChip = ui.label("", 13f, Color.WHITE, true)
        permChip.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6))
        permChip.setOnClickListener { openOverlaySettings() }
        permRow.addView(permChip)
        permCard.addView(permRow)
        root.addView(permCard, ui.lp(0, 12))

        // Çeviri motoru
        val engCard = ui.card()
        engCard.addView(ui.label("Çeviri motoru", 15f, Pal.TEXT, true), ui.lp(0, 10))
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = ui.rounded(Pal.FIELD, 12)
        seg.setPadding(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4))
        segOffline = segItem("Çevrimdışı") { Prefs.setEngine(this, "offline"); refreshEngineUi() }
        segGemini = segItem("Gemini") { Prefs.setEngine(this, "gemini"); refreshEngineUi() }
        seg.addView(segOffline, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        seg.addView(segGemini, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        engCard.addView(seg, ui.lp(0, 10))
        engineDesc = ui.label("", 12f, Pal.MUTED)
        engCard.addView(engineDesc, ui.lp(0, 12))

        // Gemini ayarları
        geminiBox = LinearLayout(this)
        geminiBox.orientation = LinearLayout.VERTICAL
        geminiBox.addView(ui.label("Gemini API anahtarı", 13f, Pal.MUTED), ui.lp(0, 6))
        geminiBox.addView(
            ui.field("AIza...", Prefs.apiKey(this), true) { Prefs.setApiKey(this, it) },
            ui.lp(0, 8)
        )
        geminiBox.addView(
            ui.button("Ücretsiz anahtar al", Pal.FIELD, Pal.ACCENT) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
            },
            ui.lp(0, 12)
        )
        geminiBox.addView(ui.label("Model", 13f, Pal.MUTED), ui.lp(0, 6))
        geminiBox.addView(
            ui.field(Prefs.DEFAULT_MODEL, Prefs.model(this), false) { Prefs.setModel(this, it) },
            ui.lp(0, 4)
        )
        engCard.addView(geminiBox)

        // Çevrimdışı dil
        langRow = LinearLayout(this)
        langRow.orientation = LinearLayout.VERTICAL
        langRow.addView(ui.label("Oyunun dili", 13f, Pal.MUTED), ui.lp(0, 6))
        langBtn = ui.button("", Pal.FIELD, Pal.TEXT) { pickLanguage() }
        langRow.addView(langBtn)
        engCard.addView(langRow)
        root.addView(engCard, ui.lp(0, 12))

        // Görünüm
        val viewCard = ui.card()
        viewCard.addView(ui.label("Altyazı yazı boyutu", 15f, Pal.TEXT, true), ui.lp(0, 10))
        val sizeRow = LinearLayout(this)
        sizeRow.orientation = LinearLayout.HORIZONTAL
        sizeRow.gravity = Gravity.CENTER_VERTICAL
        sizeRow.addView(
            ui.button("−", Pal.FIELD, Pal.TEXT) { changeSize(-2) },
            LinearLayout.LayoutParams(ui.dp(64), LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        sizeLabel = ui.label("", 18f, Pal.TEXT, true)
        sizeLabel.gravity = Gravity.CENTER
        sizeRow.addView(sizeLabel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        sizeRow.addView(
            ui.button("+", Pal.FIELD, Pal.TEXT) { changeSize(2) },
            LinearLayout.LayoutParams(ui.dp(64), LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        viewCard.addView(sizeRow)
        root.addView(viewCard, ui.lp(0, 12))

        // Nasıl kullanılır
        val help = ui.card()
        help.addView(ui.label("Nasıl kullanılır", 15f, Pal.TEXT, true), ui.lp(0, 8))
        help.addView(
            ui.label(
                "1. Başlat'a bas ve ekran yakalama iznini ver.\n" +
                    "2. PS5'e bağlan. PS5'te Ayarlar → Sistem → Uzaktan Oynama açık olmalı.\n" +
                    "3. Yayın başlayınca üstteki küçük panelden Bölge'ye bas ve yazının çıktığı yeri parmağınla çiz. Bölge kaydedilir, bir daha çizmen gerekmez.\n" +
                    "4. Altyazı, bölgenin karşı tarafında görünür. ↕ ile yerini değiştirebilirsin, ⚙ ile bu ekrana dönersin.",
                13f, Pal.MUTED
            )
        )
        root.addView(help, ui.lp(0, 0))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Pal.BG)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    private fun segItem(label: String, onClick: () -> Unit): TextView {
        val v = ui.label(label, 14f, Pal.MUTED, true)
        v.gravity = Gravity.CENTER
        v.setPadding(ui.dp(8), ui.dp(10), ui.dp(8), ui.dp(10))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun refreshAll() {
        refreshEngineUi()
        val granted = Settings.canDrawOverlays(this)
        permChip.text = if (granted) "Verildi ✓" else "İzin ver"
        permChip.background = ui.rounded(if (granted) Pal.GREEN else Pal.ACCENT, 20)
        val running = CaptureService.running
        statusChip.text = if (running) "Çalışıyor" else "Hazır"
        statusChip.background = ui.rounded(if (running) Pal.GREEN else Pal.FIELD, 20)
        mainBtn.text = if (running) "■  Durdur" else "▶  Başlat"
        mainBtn.background = ui.rounded(if (running) Pal.RED else Pal.ACCENT, 14)
        sizeLabel.text = Prefs.textSize(this).toString()
        if (Ps5Launcher.available()) {
            val cn = Ps5Launcher.consoleName(this)
            consoleInfo.text = if (cn != null) "Bağlanacak konsol: $cn" else "İlk seferde konsolunu ekleyip bağlan, sonra otomatik bağlanır"
        }
        val code = Prefs.srcLang(this)
        val idx = langCodes.indexOf(code).let { if (it < 0) 0 else it }
        langBtn.text = langNames[idx] + "  ▾"
    }

    private fun refreshEngineUi() {
        val g = Prefs.engine(this) == "gemini"
        segGemini.background = ui.rounded(if (g) Pal.ACCENT else Color.TRANSPARENT, 9)
        segOffline.background = ui.rounded(if (!g) Pal.ACCENT else Color.TRANSPARENT, 9)
        segGemini.setTextColor(if (g) Color.WHITE else Pal.MUTED)
        segOffline.setTextColor(if (!g) Color.WHITE else Pal.MUTED)
        geminiBox.visibility = if (g) View.VISIBLE else View.GONE
        langRow.visibility = if (g) View.GONE else View.VISIBLE
        engineDesc.text = if (g) {
            "Daha doğru ve doğal çeviri, her dili okur. İnternet ve API anahtarı gerekir."
        } else {
            "İnternetsiz çalışır, hızlıdır. Sadece Latin harfli diller (ilk seferde model iner)."
        }
    }

    private fun pickLanguage() {
        AlertDialog.Builder(this)
            .setTitle("Oyunun dili")
            .setItems(langNames) { _, which ->
                Prefs.setSrcLang(this, langCodes[which])
                refreshAll()
            }
            .show()
    }

    private fun changeSize(delta: Int) {
        Prefs.setTextSize(this, Prefs.textSize(this) + delta)
        sizeLabel.text = Prefs.textSize(this).toString()
    }

    private fun openOverlaySettings() {
        if (Settings.canDrawOverlays(this)) return
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun onMainClick() {
        if (CaptureService.running) {
            startService(Intent(this, CaptureService::class.java).setAction("STOP"))
            handler.postDelayed({ refreshAll() }, 500)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Önce üstte gösterme iznini ver", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        if (Prefs.engine(this) == "gemini" && Prefs.apiKey(this).isBlank()) {
            Toast.makeText(this, "Gemini anahtarını gir ya da Çevrimdışı'nı seç", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            handler.postDelayed({
                if (Ps5Launcher.available()) {
                    openMomiji()
                } else {
                    Toast.makeText(this, "Çeviri başladı. Oyunu aç, Bölge'yi seç", Toast.LENGTH_LONG).show()
                    moveTaskToBack(true)
                }
            }, 600)
        }
    }

    private fun openMomiji() {
        val i = Ps5Launcher.intent(this)
        if (i == null) {
            Toast.makeText(this, "PS5 bağlantı ekranı bulunamadı", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "PS5 bağlantı ekranı açılamadı", Toast.LENGTH_LONG).show()
        }
    }
}
