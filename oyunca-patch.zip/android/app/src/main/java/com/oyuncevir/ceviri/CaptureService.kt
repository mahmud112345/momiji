package com.oyuncevir.ceviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class CaptureService : Service() {

    companion object {
        @Volatile
        var running = false
        const val CHANNEL = "oyunca"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var capW = 0
    private var capH = 0

    private lateinit var panel: View
    private lateinit var subtitle: TextView
    private lateinit var subtitleParams: WindowManager.LayoutParams
    private lateinit var toggleChip: TextView
    private lateinit var engineChip: TextView
    private var selector: View? = null

    // Seçilen bölge: ekran boyutuna oranla (0..1)
    private var rl = 0f
    private var rt = 0f
    private var rr = 0f
    private var rb = 0f
    private var hasRegion = false

    private var translating = false
    private var busy = false
    private var subtitleAtTop = true
    private var activeEngine = ""

    // Çevrimdışı (ML Kit)
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var translator: Translator? = null
    private var translatorLang = ""
    private var modelReady = false
    private var downloading = false
    private var lastDlTry = 0L
    private var emptyCount = 0
    private var lastOcr = ""
    private var lastSrc = ""
    private var lastRaw = ""
    private var pending: Runnable? = null

    // Gemini
    private var lastSig: IntArray? = null
    private var dirty = false
    private var dirtySince = 0L
    private var lastSent = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (running) return START_NOT_STICKY

        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }
        projection?.registerCallback(projectionCallback!!, main)

        setupCapture()
        buildOverlays()
        if (Prefs.hasRegion(this)) {
            val r = Prefs.region(this)
            rl = r[0]; rt = r[1]; rr = r[2]; rb = r[3]
            hasRegion = true
            translating = true
            toggleChip.text = "⏸"
            autoPlace()
        }
        main.postDelayed(loop, 800)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Çeviri", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        val n = builder
            .setContentTitle("Oyunca çalışıyor")
            .setContentText("Durdurmak için dokun")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun realSize(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    // ---- Ekran yakalama ----

    private fun setupCapture() {
        val (w, h, dpi) = realSize()
        capW = w
        capH = h
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = vdisplay
        if (vd == null) {
            vdisplay = projection!!.createVirtualDisplay(
                "oyunca", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } else {
            vd.resize(w, h, dpi)
            vd.surface = r.surface
        }
        reader?.close()
        reader = r
    }

    private val loop = object : Runnable {
        override fun run() {
            if (translating && hasRegion && !busy) captureAndRead()
            main.postDelayed(this, 600)
        }
    }

    private fun resetState() {
        lastSig = null
        dirty = false
        lastOcr = ""
        lastSrc = ""
        lastRaw = ""
        emptyCount = 0
        pending?.let { main.removeCallbacks(it) }
        showSubtitle("")
    }

    private fun captureAndRead() {
        val (w, h, _) = realSize()
        if (w != capW || h != capH) {
            setupCapture() // ekran döndü
            return
        }
        val engine = Prefs.engine(this)
        if (engine != activeEngine) {
            activeEngine = engine
            resetState()
        }
        val image = reader?.acquireLatestImage() ?: return
        var crop: Bitmap? = null
        try {
            val plane = image.planes[0]
            val rowPx = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPx, image.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val x = (rl * image.width).toInt().coerceIn(0, image.width - 2)
            val y = (rt * image.height).toInt().coerceIn(0, image.height - 2)
            val cw = ((rr - rl) * image.width).toInt().coerceIn(2, image.width - x)
            val ch = ((rb - rt) * image.height).toInt().coerceIn(2, image.height - y)
            crop = Bitmap.createBitmap(full, x, y, cw, ch)
            full.recycle()
        } catch (e: Exception) {
            crop = null
        } finally {
            image.close()
        }
        val bmp = crop ?: return
        if (engine == "gemini") handleGemini(bmp) else handleOffline(bmp)
    }

    // ---- Gemini ----

    private fun handleGemini(bmp: Bitmap) {
        val key = Prefs.apiKey(this)
        if (key.isBlank()) {
            bmp.recycle()
            showSubtitle("Ayarlardan Gemini anahtarını gir")
            return
        }
        val sig = signature(bmp)
        val prev = lastSig
        val diff = if (prev == null) 999 else sigDiff(prev, sig)
        lastSig = sig
        val now = SystemClock.uptimeMillis()
        val stable = diff <= 8
        if (!stable && !dirty) {
            dirty = true
            dirtySince = now
        }
        if (prev == null && !dirty) {
            dirty = true
            dirtySince = now
        }
        if (dirty && !busy && (stable || now - dirtySince > 2500) && now - lastSent > 900) {
            dirty = false
            lastSent = now
            busy = true
            val model = Prefs.model(this)
            io.execute {
                val jpeg = encode(bmp)
                bmp.recycle()
                val res = GeminiClient.translateImage(key, model, jpeg)
                main.post { onGemini(res) }
            }
            return
        }
        bmp.recycle()
    }

    private fun onGemini(res: GeminiResult) {
        busy = false
        if (!translating || activeEngine != "gemini") return
        if (res.error != null) {
            showSubtitle(res.error)
            return
        }
        val t = res.text ?: ""
        if (t.isBlank() || (t.length < 8 && t.uppercase().startsWith("NONE"))) {
            showSubtitle("")
        } else {
            showSubtitle(t)
        }
    }

    private fun encode(src: Bitmap): ByteArray {
        var b = src
        if (src.width > 900) {
            val nh = (src.height * 900f / src.width).toInt().coerceAtLeast(2)
            b = Bitmap.createScaledBitmap(src, 900, nh, true)
        }
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 80, out)
        if (b !== src) b.recycle()
        return out.toByteArray()
    }

    private fun signature(src: Bitmap): IntArray {
        val sw = 48
        val sh = 16
        val s = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        s.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (s !== src) s.recycle()
        val out = IntArray(sw * sh)
        for (i in px.indices) {
            val c = px[i]
            out[i] = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
        }
        return out
    }

    private fun sigDiff(a: IntArray, b: IntArray): Int {
        if (a.size != b.size) return 999
        var sum = 0L
        for (i in a.indices) sum += Math.abs(a[i] - b[i])
        return (sum / a.size).toInt()
    }

    // ---- Çevrimdışı: OCR ve çeviri ----

    private fun handleOffline(bmp: Bitmap) {
        ensureOffline()
        busy = true
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { onOcr(it.text) }
            .addOnFailureListener { busy = false }
            .addOnCompleteListener { bmp.recycle() }
    }

    private fun ensureOffline() {
        val lang = Prefs.srcLang(this)
        if (translator == null || translatorLang != lang) {
            translator?.close()
            modelReady = false
            downloading = false
            translatorLang = lang
            translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(lang)
                    .setTargetLanguage(TranslateLanguage.TURKISH)
                    .build()
            )
        }
        val now = SystemClock.uptimeMillis()
        if (!modelReady && !downloading && now - lastDlTry > 5000) {
            downloading = true
            lastDlTry = now
            showSubtitle("Çeviri modeli indiriliyor (internet gerekir)…")
            translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    modelReady = true
                    downloading = false
                    showSubtitle("")
                    if (lastRaw.isNotEmpty()) translateNow(lastRaw, lastOcr)
                }
                .addOnFailureListener {
                    downloading = false
                    showSubtitle("Model indirilemedi, interneti kontrol et")
                }
        }
    }

    private fun onOcr(raw: String) {
        busy = false
        val text = raw.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        if (text.length < 3) {
            emptyCount++
            if (emptyCount >= 3) {
                lastOcr = ""
                lastSrc = ""
                lastRaw = ""
                pending?.let { main.removeCallbacks(it) }
                showSubtitle("")
            }
            return
        }
        emptyCount = 0
        val key = text.lowercase().filter { it.isLetterOrDigit() }
        if (key == lastOcr) return
        lastOcr = key
        lastRaw = text
        pending?.let { main.removeCallbacks(it) }
        val r = Runnable { translateNow(text, key) }
        pending = r
        main.postDelayed(r, 500) // yazı oturana kadar kısa bekle
    }

    private fun translateNow(text: String, key: String) {
        val tr = translator ?: return
        if (!modelReady) return
        if (key == lastSrc) return
        lastSrc = key
        tr.translate(text)
            .addOnSuccessListener { showSubtitle(it) }
            .addOnFailureListener { showSubtitle("Çeviri hatası") }
    }

    private fun showSubtitle(t: String) {
        if (!::subtitle.isInitialized) return
        if (t.isBlank()) {
            subtitle.visibility = View.GONE
            return
        }
        if (subtitle.visibility == View.VISIBLE && subtitle.text.toString() == t) return
        val (w, _, _) = realSize()
        subtitle.maxWidth = (w * 0.9).toInt()
        subtitle.textSize = Prefs.textSize(this).toFloat()
        subtitle.text = t
        subtitle.visibility = View.VISIBLE
    }

    // ---- Üstte görünen arayüz ----

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = label
        v.setTextColor(Color.WHITE)
        v.textSize = 15f
        v.setPadding(dp(12), dp(8), dp(12), dp(8))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun overlayParams(w: Int, h: Int, flags: Int): WindowManager.LayoutParams {
        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(w, h, type, flags, PixelFormat.TRANSLUCENT)
    }

    private fun engineLabel(): String =
        if (Prefs.engine(this) == "gemini") "Gemini" else "Offline"

    private fun buildOverlays() {
        // Altyazı
        subtitle = TextView(this)
        subtitle.setTextColor(Color.WHITE)
        subtitle.textSize = Prefs.textSize(this).toFloat()
        subtitle.gravity = Gravity.CENTER
        subtitle.setPadding(dp(16), dp(10), dp(16), dp(10))
        val sbg = GradientDrawable()
        sbg.setColor(0xD9000000.toInt())
        sbg.cornerRadius = dp(12).toFloat()
        subtitle.background = sbg
        subtitle.visibility = View.GONE
        subtitleParams = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
        subtitleParams.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        subtitleParams.y = dp(24)
        wm.addView(subtitle, subtitleParams)

        // Kontrol paneli
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val bbg = GradientDrawable()
        bbg.setColor(0xE6151B2B.toInt())
        bbg.cornerRadius = dp(22).toFloat()
        bbg.setStroke(dp(1), 0x554F8CFF)
        bar.background = bbg
        bar.setPadding(dp(4), dp(2), dp(4), dp(2))

        val panelParams = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        panelParams.gravity = Gravity.TOP or Gravity.START
        panelParams.x = 0
        panelParams.y = dp(90)

        val handle = chip("≡") {}
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = panelParams.x; startY = panelParams.y
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = startX + (e.rawX - downX).toInt()
                    panelParams.y = startY + (e.rawY - downY).toInt()
                    wm.updateViewLayout(panel, panelParams)
                }
            }
            true
        }

        toggleChip = chip("▶") {
            if (hasRegion) {
                translating = !translating
                toggleChip.text = if (translating) "⏸" else "▶"
                if (!translating) showSubtitle("") else resetState()
            }
        }
        engineChip = chip(engineLabel()) {
            val next = if (Prefs.engine(this) == "gemini") "offline" else "gemini"
            Prefs.setEngine(this, next)
            engineChip.text = engineLabel()
            showSubtitle("")
        }

        bar.addView(handle)
        bar.addView(chip("Bölge") { startSelecting() })
        bar.addView(toggleChip)
        bar.addView(engineChip)
        bar.addView(chip("↕") { moveSubtitle() })
        bar.addView(chip("⚙") {
            startActivity(
                Intent(this, CeviriActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        })
        bar.addView(chip("✕") { stopSelf() })
        panel = bar
        wm.addView(panel, panelParams)
    }

    private fun applySubtitleGravity() {
        subtitleParams.gravity =
            (if (subtitleAtTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        subtitleParams.y = dp(24)
        if (::subtitle.isInitialized) wm.updateViewLayout(subtitle, subtitleParams)
    }

    private fun moveSubtitle() {
        subtitleAtTop = !subtitleAtTop
        applySubtitleGravity()
    }

    // Altyazıyı, seçilen bölgenin karşı yarısına koy (kendi yazısını okumasın)
    private fun autoPlace() {
        subtitleAtTop = (rt + rb) / 2f > 0.5f
        applySubtitleGravity()
    }

    // ---- Bölge seçme ----

    private fun startSelecting() {
        if (selector != null) return
        val v = SelectView(this) { l, t, r, b -> finishSelect(l, t, r, b) }
        val p = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        wm.addView(v, p)
        selector = v
    }

    private fun removeSelector() {
        selector?.let { runCatching { wm.removeView(it) } }
        selector = null
    }

    private fun finishSelect(l: Int, t: Int, r: Int, b: Int) {
        removeSelector()
        if (l < 0) return
        val (w, h, _) = realSize()
        rl = (l / w.toFloat()).coerceIn(0f, 1f)
        rr = (r / w.toFloat()).coerceIn(0f, 1f)
        rt = (t / h.toFloat()).coerceIn(0f, 1f)
        rb = (b / h.toFloat()).coerceIn(0f, 1f)
        Prefs.saveRegion(this, rl, rt, rr, rb)
        hasRegion = true
        translating = true
        toggleChip.text = "⏸"
        resetState()
        autoPlace()
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) {
            runCatching { wm.removeView(panel) }
            runCatching { wm.removeView(subtitle) }
            removeSelector()
        }
        io.shutdownNow()
        vdisplay?.release()
        reader?.close()
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        recognizer.close()
        translator?.close()
        super.onDestroy()
    }
}

private class SelectView(
    ctx: Context,
    val onDone: (Int, Int, Int, Int) -> Unit
) : View(ctx) {
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var drawing = false
    private val rectPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 44f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    init {
        setBackgroundColor(0x66000000)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y; ex = sx; ey = sy; drawing = true
            }
            MotionEvent.ACTION_MOVE -> {
                ex = e.x; ey = e.y
            }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y; drawing = false
                val loc = IntArray(2)
                getLocationOnScreen(loc)
                val l = minOf(sx, ex).toInt() + loc[0]
                val t = minOf(sy, ey).toInt() + loc[1]
                val r = maxOf(sx, ex).toInt() + loc[0]
                val b = maxOf(sy, ey).toInt() + loc[1]
                if (r - l > 40 && b - t > 20) onDone(l, t, r, b) else onDone(-1, -1, -1, -1)
                return true
            }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        if (!drawing) {
            c.drawText("Çevrilecek yazının üstünü parmağınla çiz", width / 2f, height / 2f, textPaint)
        } else {
            c.drawRect(minOf(sx, ex), minOf(sy, ey), maxOf(sx, ex), maxOf(sy, ey), rectPaint)
        }
    }
}
