package com.oyuncevir.ceviri

import android.content.Context

object Prefs {
    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"

    private fun sp(c: Context) = c.getSharedPreferences("oyunca", Context.MODE_PRIVATE)

    fun engine(c: Context): String = sp(c).getString("engine", "offline") ?: "offline"
    fun setEngine(c: Context, v: String) {
        sp(c).edit().putString("engine", v).apply()
    }

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) {
        sp(c).edit().putString("key", v.trim()).apply()
    }

    fun model(c: Context): String {
        val m = (sp(c).getString("model", "") ?: "").trim()
        return if (m.isEmpty()) DEFAULT_MODEL else m
    }
    fun setModel(c: Context, v: String) {
        sp(c).edit().putString("model", v.trim()).apply()
    }

    fun srcLang(c: Context): String = sp(c).getString("lang", "en") ?: "en"
    fun setSrcLang(c: Context, v: String) {
        sp(c).edit().putString("lang", v).apply()
    }

    fun textSize(c: Context): Int = sp(c).getInt("tsize", 20)
    fun setTextSize(c: Context, v: Int) {
        sp(c).edit().putInt("tsize", v.coerceIn(12, 36)).apply()
    }

    fun hasRegion(c: Context): Boolean = sp(c).getBoolean("hasRegion", false)
    fun region(c: Context): FloatArray {
        val p = sp(c)
        return floatArrayOf(
            p.getFloat("rl", 0f), p.getFloat("rt", 0f),
            p.getFloat("rr", 0f), p.getFloat("rb", 0f)
        )
    }
    fun saveRegion(c: Context, l: Float, t: Float, r: Float, b: Float) {
        sp(c).edit()
            .putFloat("rl", l).putFloat("rt", t).putFloat("rr", r).putFloat("rb", b)
            .putBoolean("hasRegion", true)
            .apply()
    }
}
