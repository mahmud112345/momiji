package com.oyuncevir.ceviri

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiResult(val text: String?, val error: String?)

object GeminiClient {

    private const val PROMPT =
        "Bu görüntü bir video oyunundan alınmış altyazı ya da diyalog yazısı. " +
        "Görüntüdeki yazıyı oku ve doğal, akıcı, günlük Türkçeye çevir. " +
        "Sadece Türkçe çeviriyi yaz. Açıklama, tırnak işareti ya da etiket ekleme. " +
        "Konuşan karakterin adı varsa \"Ad: konuşma\" biçiminde koru. " +
        "Görüntüde okunabilir yazı yoksa sadece NONE yaz."

    fun translateImage(apiKey: String, model: String, jpeg: ByteArray): GeminiResult {
        var conn: HttpURLConnection? = null
        try {
            val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
            val parts = JSONArray()
                .put(JSONObject().put("text", PROMPT))
                .put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg").put("data", b64)
                    )
                )
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                .put(
                    "generationConfig",
                    JSONObject().put("temperature", 0.2).put("maxOutputTokens", 1024)
                )

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 20000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val hint = when (code) {
                    400 -> "model adı ya da anahtar hatalı olabilir"
                    401, 403 -> "API anahtarı geçersiz"
                    404 -> "model bulunamadı, ayarlardan model adını kontrol et"
                    429 -> "istek sınırı doldu, biraz bekle"
                    else -> "sunucu hatası"
                }
                return GeminiResult(null, "Gemini hatası ($code): $hint")
            }
            val root = JSONObject(resp)
            val cands = root.optJSONArray("candidates")
            if (cands == null || cands.length() == 0) return GeminiResult("", null)
            val partsOut = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (partsOut != null) {
                for (i in 0 until partsOut.length()) {
                    sb.append(partsOut.getJSONObject(i).optString("text", ""))
                }
            }
            return GeminiResult(sb.toString().trim(), null)
        } catch (e: Exception) {
            return GeminiResult(null, "Gemini'ye ulaşılamadı, interneti kontrol et")
        } finally {
            conn?.disconnect()
        }
    }
}
