package com.oyuncevir.ceviri

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object Pal {
    val BG = 0xFF0B0F1A.toInt()
    val CARD = 0xFF151B2B.toInt()
    val FIELD = 0xFF1E2640.toInt()
    val ACCENT = 0xFF4F8CFF.toInt()
    val GREEN = 0xFF22C55E.toInt()
    val RED = 0xFFEF4444.toInt()
    val TEXT = 0xFFE8ECF5.toInt()
    val MUTED = 0xFF8A94AA.toInt()
}

class UiKit(private val ctx: Context) {
    private val density = ctx.resources.displayMetrics.density

    fun dp(v: Int): Int = (v * density).toInt()

    fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        p.setMargins(0, dp(top), 0, dp(bottom))
        return p
    }

    fun label(t: String, size: Float = 15f, color: Int = Pal.TEXT, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    fun card(): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(Pal.CARD, 18)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        return c
    }

    fun button(text: String, bg: Int, fg: Int = Color.WHITE, onClick: () -> Unit): TextView {
        val v = TextView(ctx)
        v.text = text
        v.textSize = 16f
        v.setTextColor(fg)
        v.gravity = Gravity.CENTER
        v.setTypeface(v.typeface, Typeface.BOLD)
        v.background = rounded(bg, 14)
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        v.setOnClickListener { onClick() }
        return v
    }

    fun field(hintText: String, initial: String, password: Boolean, onChange: (String) -> Unit): EditText {
        val e = EditText(ctx)
        e.setText(initial)
        e.setHint(hintText)
        e.setTextColor(Pal.TEXT)
        e.setHintTextColor(Pal.MUTED)
        e.textSize = 15f
        e.inputType = if (password) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        e.background = rounded(Pal.FIELD, 12)
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                onChange(s?.toString() ?: "")
            }
        })
        return e
    }
}
