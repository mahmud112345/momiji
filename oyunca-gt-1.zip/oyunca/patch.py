"""GameTranslator mobil uygulamasini Oyunca'ya donusturur: ad, siyah altyazi ekrani, alan secme, ayar paneli.
Depo kokunden calistirilir: python3 oyunca/patch.py"""
import pathlib
import shutil
import sys

root = pathlib.Path(".")
mobile = root / "mobile"
here = pathlib.Path(__file__).parent


def need(path):
    if not path.exists():
        sys.exit("HATA: bulunamadi: %s (bu dosya GameTranslator deposunun kokunde calismali)" % path)
    return path


def edit(path, old, new, label, required=True):
    text = need(path).read_text(encoding="utf-8")
    if new in text:
        print("zaten yamali:", label)
        return
    if old not in text:
        if required:
            sys.exit("HATA: yama noktasi bulunamadi: %s (%s)" % (label, path))
        print("atlandi:", label)
        return
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print("yamalandi:", label)


# 1) Yeni ekran
shutil.copy(here / "oyunca_screen.dart", need(mobile / "lib") / "oyunca_screen.dart")
print("eklendi: lib/oyunca_screen.dart")

# 2) Bagimliliklar
edit(mobile / "pubspec.yaml", "  http: ^1.6.0\n",
     "  http: ^1.6.0\n  shared_preferences: ^2.3.0\n  wakelock_plus: ^1.2.0\n", "pubspec bagimliliklari")

# 3) Ad
edit(mobile / "android/app/src/main/AndroidManifest.xml",
     'android:label="GameTranslator"', 'android:label="Oyunca"', "uygulama adi")
edit(mobile / "lib/main.dart", "title: 'GameTranslator',", "title: 'Oyunca',", "MaterialApp adi")
edit(mobile / "lib/home_page.dart", "title: 'GameTranslator',", "title: 'Oyunca',", "ana ekran basligi", required=False)

# 4) Ana ekrana "Altyazi ekranini ac" dugmesi
home = mobile / "lib/home_page.dart"
edit(home, "import 'main.dart';\n", "import 'main.dart';\nimport 'oyunca_screen.dart';\n", "home import")
edit(home, "        FlowRow(nodes: nodes),\n",
     "        FlowRow(nodes: nodes),\n"
     "        const SizedBox(height: 14),\n"
     "        Group(\n"
     "          inset: 60,\n"
     "          children: [\n"
     "            Cell(\n"
     "              icon: CupertinoIcons.captions_bubble_fill,\n"
     "              iconColor: Tokens.indigo,\n"
     "              title: 'Altyazı ekranını aç (siyah ekran)',\n"
     "              chevron: true,\n"
     "              onTap: () => Navigator.of(context).push(appleRoute<void>((_) => const OyuncaScreen())),\n"
     "            ),\n"
     "          ],\n"
     "        ),\n", "altyazi ekrani dugmesi")

# 5) Eksik tanitim gorseli (depoda yoksa logo ile doldurulur; yalniz derleme icin)
scene = mobile / "assets/intro_scene.jpg"
if not scene.exists():
    shutil.copy(need(mobile / "assets/logo.png"), scene)
    print("eklendi: assets/intro_scene.jpg (yer tutucu)")
print("Tamam.")
