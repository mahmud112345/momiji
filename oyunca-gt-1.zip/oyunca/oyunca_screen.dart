// SPDX-License-Identifier: AGPL-3.0-only
import 'dart:async';
import 'dart:typed_data';

import 'package:material_ui/material_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'bridge.dart';

/// Oyunca altyazı ekranı: tamamen siyah zemin, çeviri üstte. Oyun görüntüsü telefonda gösterilmez;
/// PS5 görüntüsü arka planda okunur. Sol kenardan sağa çekince ayar paneli açılır.
class OyuncaScreen extends StatefulWidget {
  const OyuncaScreen({super.key});

  @override
  State<OyuncaScreen> createState() => _OyuncaScreenState();
}

class _OyuncaScreenState extends State<OyuncaScreen> {
  // Görünüm ayarları (telefonda kalır)
  double fontSize = 26;
  double topPercent = 12; // ekranın üstünden % konum
  double bgOpacity = 0; // yazının arkasındaki kutu, 0-100
  bool bold = true;
  int colorIndex = 0;
  int fontIndex = 0;

  static const colors = [Color(0xFFFFFFFF), Color(0xFFFACC15), Color(0xFF64D2FF), Color(0xFF30D158)];
  static const fonts = [('Inter', 'Inter'), ('Sistem', ''), ('Serif', 'serif'), ('Mono', 'monospace')];

  EngineState state = const EngineState();
  StreamSubscription<EngineState>? sub;
  String shown = '';
  int lastCount = -1;
  Timer? hideTimer;

  bool panelOpen = false;
  bool picking = false;
  Uint8List? snapshot;
  Offset? dragStart;
  Offset? dragEnd;
  Size pickSize = const Size(1, 1);
  AppSettings? settings;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    loadPrefs();
    Bridge.settings().then((s) {
      if (mounted) setState(() => settings = s);
    });
    Bridge.state().then(onState);
    sub = Bridge.states.listen(onState);
  }

  @override
  void dispose() {
    sub?.cancel();
    hideTimer?.cancel();
    WakelockPlus.disable();
    super.dispose();
  }

  void onState(EngineState next) {
    if (!mounted) return;
    setState(() {
      state = next;
      if (next.translated != lastCount) {
        lastCount = next.translated;
        if (next.lastTranslation.isNotEmpty) {
          shown = next.lastTranslation;
          hideTimer?.cancel();
          final ms = (2000 + shown.length * 60).clamp(2000, 8000);
          hideTimer = Timer(Duration(milliseconds: ms), () {
            if (mounted) setState(() => shown = '');
          });
        }
      }
    });
  }

  Future<void> loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      fontSize = p.getDouble('o_font') ?? fontSize;
      topPercent = p.getDouble('o_top') ?? topPercent;
      bgOpacity = p.getDouble('o_bg') ?? bgOpacity;
      bold = p.getBool('o_bold') ?? bold;
      colorIndex = p.getInt('o_color') ?? colorIndex;
      fontIndex = p.getInt('o_fontidx') ?? fontIndex;
    });
  }

  Future<void> savePrefs() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('o_font', fontSize);
    await p.setDouble('o_top', topPercent);
    await p.setDouble('o_bg', bgOpacity);
    await p.setBool('o_bold', bold);
    await p.setInt('o_color', colorIndex);
    await p.setInt('o_fontidx', fontIndex);
  }

  Future<void> startPicking() async {
    final image = await Bridge.snapshot(width: 960);
    if (!mounted) return;
    if (image == null) {
      ScaffoldMessenger.maybeOf(context)?.showSnackBar(const SnackBar(content: Text('Görüntü henüz gelmedi. Bağlanınca tekrar dene.')));
      return;
    }
    setState(() {
      snapshot = image;
      picking = true;
      panelOpen = false;
      dragStart = null;
      dragEnd = null;
    });
  }

  Future<void> finishPicking(Size size) async {
    final a = dragStart;
    final b = dragEnd;
    setState(() => picking = false);
    final s = settings;
    if (a == null || b == null || s == null) return;
    double f(double v, double max) => (v / max).clamp(0.0, 1.0);
    final left = f(a.dx < b.dx ? a.dx : b.dx, size.width);
    final right = f(a.dx < b.dx ? b.dx : a.dx, size.width);
    final top = f(a.dy < b.dy ? a.dy : b.dy, size.height);
    final bottom = f(a.dy < b.dy ? b.dy : a.dy, size.height);
    if (right - left < 0.05 || bottom - top < 0.03) return;
    s.json['region'] = {'top': top, 'bottom': bottom, 'left': left, 'right': right};
    await Bridge.saveSettings(s);
  }

  String get statusText => switch (state.phase) {
        'streaming' => '',
        'starting' => 'Başlatılıyor…',
        'connecting' => 'PS5\'e bağlanılıyor…',
        'waking' => 'PS5 uyandırılıyor…',
        'reconnecting' => 'Yeniden bağlanılıyor…',
        'failed' => state.message.isEmpty ? 'Başlatılamadı' : state.message,
        _ => 'Çeviri kapalı. Sol kenardan çekip ayarları aç.',
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: picking ? pickerView() : mainView(),
    );
  }

  Widget mainView() {
    final size = MediaQuery.sizeOf(context);
    final text = shown.isNotEmpty ? shown : statusText;
    final isStatus = shown.isEmpty;
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned(
          left: 16,
          right: 16,
          top: size.height * topPercent / 100,
          child: Center(
            child: text.isEmpty
                ? const SizedBox.shrink()
                : Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: isStatus ? 0 : bgOpacity / 100),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      text,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: isStatus ? const Color(0x99FFFFFF) : colors[colorIndex],
                        fontSize: isStatus ? 15 : fontSize,
                        fontWeight: bold && !isStatus ? FontWeight.w700 : FontWeight.w400,
                        fontFamily: fonts[fontIndex].$2.isEmpty ? null : fonts[fontIndex].$2,
                        height: 1.25,
                      ),
                    ),
                  ),
          ),
        ),
        // Sol kenar: sağa çekince ayar paneli açılır.
        Positioned(
          left: 0,
          top: 0,
          bottom: 0,
          width: 28,
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onHorizontalDragUpdate: (d) {
              if (d.delta.dx > 4 && !panelOpen) setState(() => panelOpen = true);
            },
            onTap: () => setState(() => panelOpen = true),
          ),
        ),
        if (panelOpen) Positioned.fill(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: closePanel, child: const SizedBox.expand())),
        AnimatedPositioned(
          duration: const Duration(milliseconds: 180),
          left: panelOpen ? 0 : -340,
          top: 0,
          bottom: 0,
          width: 320,
          child: panel(),
        ),
      ],
    );
  }

  void closePanel() {
    setState(() => panelOpen = false);
    savePrefs();
  }

  Widget panel() {
    return Container(
      color: const Color(0xF2161618),
      padding: EdgeInsets.fromLTRB(18, MediaQuery.paddingOf(context).top + 12, 18, 16),
      child: ListView(
        children: [
          const Text('Oyunca', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(state.phase == 'streaming' ? 'PS5 bağlı, çeviri açık' : (statusText.isEmpty ? '' : statusText),
              style: const TextStyle(color: Color(0x99FFFFFF), fontSize: 13)),
          const SizedBox(height: 14),
          row(state.running ? 'Çeviriyi durdur' : 'Çeviriyi başlat', () async {
            if (state.running) {
              await Bridge.stop();
            } else {
              await Bridge.start();
            }
          }),
          row('Okunacak alanı seç', startPicking),
          const SizedBox(height: 8),
          label('Yazı boyutu  ${fontSize.round()}'),
          CupertinoSlider(value: fontSize, min: 14, max: 56, onChanged: (v) => setState(() => fontSize = v)),
          label('Konum (yukarıdan)  %${topPercent.round()}'),
          CupertinoSlider(value: topPercent, min: 0, max: 85, onChanged: (v) => setState(() => topPercent = v)),
          label('Arka plan kutusu  %${bgOpacity.round()}'),
          CupertinoSlider(value: bgOpacity, min: 0, max: 100, onChanged: (v) => setState(() => bgOpacity = v)),
          label('Yazı tipi'),
          Wrap(spacing: 8, children: [
            for (var i = 0; i < fonts.length; i++) chip(fonts[i].$1, fontIndex == i, () => setState(() => fontIndex = i)),
          ]),
          const SizedBox(height: 10),
          label('Renk'),
          Wrap(spacing: 10, children: [
            for (var i = 0; i < colors.length; i++)
              GestureDetector(
                onTap: () => setState(() => colorIndex = i),
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: colors[i],
                    shape: BoxShape.circle,
                    border: Border.all(color: colorIndex == i ? const Color(0xFF0A84FF) : Colors.transparent, width: 3),
                  ),
                ),
              ),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            const Expanded(child: Text('Kalın yazı', style: TextStyle(color: Colors.white, fontSize: 15))),
            CupertinoSwitch(value: bold, onChanged: (v) => setState(() => bold = v)),
          ]),
          const SizedBox(height: 14),
          row('Kapat', () {
            savePrefs();
            Navigator.of(context).maybePop();
          }),
        ],
      ),
    );
  }

  Widget label(String t) => Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 2),
        child: Text(t, style: const TextStyle(color: Color(0xB3FFFFFF), fontSize: 13)),
      );

  Widget row(String t, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 14),
          decoration: BoxDecoration(color: const Color(0x26FFFFFF), borderRadius: BorderRadius.circular(12)),
          child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
        ),
      );

  Widget chip(String t, bool on, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: on ? const Color(0xFF0A84FF) : const Color(0x26FFFFFF),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 14)),
        ),
      );

  /// Alan seçme: PS5'ten gelen bir kare gösterilir, parmakla dikdörtgen çizilir.
  Widget pickerView() {
    final ratio = state.frameWidth > 0 && state.frameHeight > 0 ? state.frameWidth / state.frameHeight : 16 / 9;
    return SafeArea(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('Altyazının çıktığı yeri parmağınla çiz', style: TextStyle(color: Colors.white, fontSize: 15)),
          ),
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: ratio,
                child: LayoutBuilder(builder: (context, c) {
                  final size = Size(c.maxWidth, c.maxHeight);
                  pickSize = size;
                  Offset clamp(Offset o) => Offset(o.dx.clamp(0.0, size.width), o.dy.clamp(0.0, size.height));
                  final a = dragStart;
                  final b = dragEnd;
                  return GestureDetector(
                    onPanStart: (d) => setState(() {
                      dragStart = clamp(d.localPosition);
                      dragEnd = dragStart;
                    }),
                    onPanUpdate: (d) => setState(() => dragEnd = clamp(d.localPosition)),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.memory(snapshot!, fit: BoxFit.fill, gaplessPlayback: true),
                        if (a != null && b != null)
                          Positioned.fromRect(
                            rect: Rect.fromPoints(a, b),
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(0x330A84FF),
                                border: Border.all(color: const Color(0xFF0A84FF), width: 2),
                              ),
                            ),
                          ),
                      ],
                    ),
                  );
                }),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: row('Vazgeç', () => setState(() => picking = false))),
                const SizedBox(width: 10),
                Expanded(
                  child: row('Kaydet', () => finishPicking(pickSize)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
